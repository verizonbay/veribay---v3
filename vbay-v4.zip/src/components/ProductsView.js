import React from 'react'
import Product from './Product';
import { connect } from 'react-redux';
import { fetchProducts, selectproduct } from '../Actions';
import Sell from './Sell';
import { Button } from 'react-bootstrap';
import '../../node_modules/font-awesome/css/font-awesome.min.css';

//import  '../styles1.css'


class ProductsView extends React.Component {

    constructor() {
        super()
        this.state = {
            addModalShow: false,
            showProduct: false
        }
    }



    componentDidMount() {
        this.props.fetchProducts();
    }

    goBack = () => {
        this.setState({
            showProduct: false
        })
    }

    goToSell = () => {
        this.setState({
            showSell: true
        })
    }

    displayProduct = (event) => {

        this.props.showwish(!this.state.showProduct)
        console.log(this.props.productsList)
        if (localStorage.getItem("userData") == null) {
            alert("Please Login First")
            return
        }
        console.log("here", this.props.productsList[event.target.name]);
        this.props.selectproduct(this.props.productsList[event.target.name]);

        this.setState({
            showProduct: true,
            productId: event.target.name
        })
    }

    handleSubmit = (event) => {
        // alert("hi")
    }

    render() {

        let products = (this.props.productsList.length > 0) ? this.props.productsList.map(
            (product, id) =>

                // <div key={id}>

                //     <div >
                //         <hr />

                //         <div className="card">
                //             {/* <div className="card-title">
                //             <h5>{product.username}</h5>
                //         </div> */}
                //             <div className="row" >
                //                 <div className="column left" style={{ width: "20%" }}>
                //                     {
                //                         <img style={{
                //                             border: "1px solid #ddd",
                //                             borderradius: "3px",
                //                             padding: "4px",
                //                             width: "200px",
                //                             margintop: "2%",
                //                             marginright: "5%",
                //                             marginleft: "5%"
                //                         }} 
                //                         alt = "../assets/profilePic2.jpg"
                //                         src={`data:image/png;base64,${product.product_images}`} />
                //                     }
                //                 </div>
                //                 <div className="column right" style={{ width: "80%" }}>

                //                     <div>
                //                         <h3> {product.product_name}</h3>
                //                         {product.short_desc}<br />
                //                         <h5> ${product.product_price}</h5>
                //                         <i className="fa fa-heart-o" aria-hidden="true" onClick = {this.handleSubmit} style={{color:"",fontSize:"150%"}}> </i>
                //                         {/* <i class="fas fa-heart"></i> */}
                //                         <table>
                //                             <tbody>
                //                                 <tr>
                //                                     <td>

                //                                         <button className="btn btn-outline-primary " name={id} onClick={this.displayProduct}>
                //                                             Add to cart
                //                                     </button>
                //                                     </td>
                //                                 </tr>
                //                             </tbody>
                //                         </table>
                //                     </div>
                //                 </div>
                //             </div>
                //         </div>
                //         <br />
                //     </div>
                // </div>

                // tanuj code 
                <div className="container"  key={id}>
                    <div className="row" style={{ backgroundcolor: "#ffffff",
            margin:"20px 0px",
            border:"1px solid #f2f3f4",
  	borderradius:"2px"}}>
                    <div className="col-sm-12 d-flex justify-content-center">
                        <div className="p-2 bd-highlight">
                            <div className="card" >
                                <img className="card-img-top" alt="../assets/profilePic2.jpg"
                                    src={`data:image/png;base64,${product.product_images}`} style={{ width: "200px", height: "220px" }} />
                            </div>
                        </div>

                        <div className="p-2 bd-highlight flex-grow-1">
                            <div className="card" style={{ height: "220px" }}>
                                <div className="card-header">
                                {product.product_name}
                      </div>
                                <div className="card-body">
                                    {/* <h5 className="card-title">{product.product_name}</h5> */}
                                    {/* <a href="#" class="badge badge-secondary"><cite title="Source Title">Product Type</cite></a> */}
                                    <p className="card-text"> {product.short_desc}</p>
                                    <h3><b>${product.product_price}</b></h3>
                                    
                                    <button className="btn btn-outline-primary " name={id} onClick={this.displayProduct}>
                                        Add to cart
                                                     </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div >






        ) : <div>

        </div>
        let addModalClose = () =>
            this.setState({ addModalShow: false },

            );

        return (
            <React.Fragment>

                <div>



                    {this.state.showProduct ?
                        <React.Fragment>
                            {/* {console.log(this.state.product.product_images)} */}
                            <button className="btn btn-outline-primary" onClick={this.goBack}>Back</button>
                            <Product id={this.state.productId} />
                        </React.Fragment>
                        :
                        <div>
                            {localStorage.getItem("userData") ?
                                <div>
                                    <h3>Buy/Sell Products</h3>
                                    <h4>Make room in your closet for new favourites</h4>

                                    <Button variant='primary' onClick={() => this.setState({ addModalShow: true })}
                                    >Add Product</Button>
                                    <Sell show={this.state.addModalShow} onHide={addModalClose} />
                                </div>
                                :
                                <div></div>
                            }
                            <div> {products}</div>
                        </div>
                    }
                </div>

            </React.Fragment>


        )
    }
}
const mapStateToProps = state => ({ productsList: state.proddatas });
export default connect(mapStateToProps, { fetchProducts, selectproduct })(ProductsView);
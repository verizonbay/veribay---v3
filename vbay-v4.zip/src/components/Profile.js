import React from 'react'

export default class Profile extends React.Component {
    render(){
        return(
            <React.Fragment>
                <div>
                    Profile
                </div>
            </React.Fragment>
        )
    }
}
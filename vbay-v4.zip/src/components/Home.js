import React from 'react'
import ProductsView from './ProductsView';
import Wishlist from './Wishlist';

export default class Home extends React.Component {

    constructor() {
        super();
        this.state = {
            showWishListComponent: false
        }
    }
    showWishlist = (showwish) =>{
        this.setState({
            showWishListComponent :  showwish
        })
     
    }

    render() {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-2">

                    </div>
                    <div className="col-md-8">
                        <ProductsView showwish = {this.showWishlist} />
                    </div>
                    <div className="col-md-2">
                        { !this.state.showWishListComponent && localStorage.getItem("userData") &&
                                 <Wishlist />
                        }
                    </div>
                </div>
            </div>
        )
    }
}
import React from 'react';

export default class Wishlist extends React.Component {

    handleSubmit = () => {
        alert("hi")
    }
    render() {
        return (
            <div>
                <button className="btn btn-success" type="submit" onClick={this.handleSubmit}>Add to wishlist</button>
            </div>
        )
    }
}
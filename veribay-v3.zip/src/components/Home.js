import React from 'react'
import ProductsView from './ProductsView';
import Wishlist from './Wishlist';

export default class Home extends React.Component {
    render() {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-2">

                    </div>
                    <div className="col-md-8">
                        <ProductsView />
                    </div>
                    <div className="col-md-2">
                        <Wishlist />
                    </div>
                </div>


            </div>
        )
    }
}
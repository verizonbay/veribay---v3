import React from 'react'
import axios from 'axios'
import Product from './Product';
import { connect } from 'react-redux';
import { fetchProducts } from '../Actions';
import Sell from './Sell';
import { Button } from 'react-bootstrap';
//import  '../styles1.css'


class ProductsView extends React.Component {

    constructor() {
        super()
        this.state = {
            addModalShow: false
        }
    }



    componentDidMount() {
        this.props.fetchProducts();
    }

    goBack = () => {
        this.setState({
            showProduct: false
        })
    }

    goToSell = () => {
        this.setState({
            showSell: true
        })
    }

    displayProduct = (event) => {

        if (localStorage.getItem("userData") == null) {
            alert("Please Login First")
            return
        }
        this.setState({
            showProduct: true,
            productId: event.target.name
        })
    }

    render() {

        let products = (this.props.productsList.length > 0) ? this.props.productsList.map(
            (product, id) =>

                <div>

                    <div key={id} >
                        <hr />
                        {/* <h3>Buy/Sell Products</h3>   
                    <h4>Make room in your closet for new facourites</h4> */}

                        <div className="card">
                            {/* <div className="card-title">
                            <h5>{product.username}</h5>
                        </div> */}
                            <div className="row" >
                                <div className="column left" style={{ width: "20%" }}>
                                    {
                                        <img style={{
                                            border: "1px solid #ddd",
                                            borderradius: "3px",
                                            padding: "4px",
                                            width: "200px",
                                            margintop: "2%",
                                            marginright: "5%",
                                            marginleft: "5%"
                                        }} src={`data:image/png;base64,${product.product_images}`} />
                                    }
                                </div>
                                <div className="column right" style={{ width: "80%" }}>

                                    <div>
                                        <h3> {product.product_name}</h3>
                                        {product.short_desc}<br />
                                        <h5> ${product.product_price}</h5>
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <button className="btn btn-outline-primary " name={id} onClick={this.displayProduct}>
                                                            Add to cart
                                                    </button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br />
                    </div>
                </div>

        ) : <div>

            </div>
        let addModalClose = () =>
            this.setState({ addModalShow: false },

            );

        return (
            <React.Fragment>

                <div>



                    {this.state.showProduct ?
                        <React.Fragment>
                            <Product id={this.state.productId} productList={this.props.productsList} />
                            <button className="btn btn-outline-primary" onClick={this.goBack}>Back</button>
                        </React.Fragment>
                        :
                        <div>
                            { localStorage.getItem("userData")?
                                <div>
                                    <h3>Buy/Sell Products</h3>
                                    <h4>Make room in your closet for new favourites</h4>
                                    <Button variant='primary' onClick={() => this.setState({ addModalShow: true })}
                                    >Add Product</Button>
                                    <Sell show={this.state.addModalShow} onHide={addModalClose} />
                                </div>
                                :
                                <div></div>
                            }
                            <div> {products}</div>
                        </div>
                    }
                </div>

            </React.Fragment>


        )
    }
}
const mapStateToProps = state => ({ productsList: state.proddatas });
export default connect(mapStateToProps, { fetchProducts })(ProductsView);
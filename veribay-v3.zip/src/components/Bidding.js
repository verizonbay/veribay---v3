import React from 'react';
import Product from './Product';

export default class Bidding extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
         bidlist : [],
         bid:'',
         minbid:this.props.minbid,
         maxbid: this.props.minbid
        }  
    }

    componentDidMount = () => {
        
    }

    handleChange = (event) => {
        this.setState({
            [event.target.name] : event.target.value
        })
    }

    handleSubmit = (event) => {
        if (this.state.bid > this.state.maxbid) {
            this.setState({
                maxbid: this.state.bid,
                bidlist : [...this.state.bidlist,this.state.bid],
                bid: ''  
            })
        }
        event.preventDefault();     
    }

    render() {
    // let bidding = this.state.bidlist.map(
    //     (bidd, id) => 
    //     <div key= {id}>
    //         {bidd.maxbid}
    //     </div>

    // )
   
     return(
            <React.Fragment>
                   Starting bid:&nbsp;&nbsp;&nbsp;&nbsp;Rs.{this.props.minbid}<br/>                
               <input type="text" name="bid" style={{marginLeft : '105px'}} onChange={this.handleChange}/> 
               <button className="btn btn-outline-primary" onClick={this.handleSubmit}>Place bid</button><br/>
               {/* {this.state.bidlist.length}>0  */}           
               <h6 style={{marginLeft : '105px'}}>Enter Rs.{this.state.maxbid} or more</h6><br/><br/>
               {console.log(this.state.bidlist)}
              {this.state.bidlist}
              
               
            </React.Fragment>
        )
    }
}
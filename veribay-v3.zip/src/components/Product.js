import React from 'react'
import profile from '../assets/profilePic2.jpg';
//import AwesomeSlider from 'react-awesome-slider';
import '../styles.css';
import Bidding from '../components/Bidding';
import { Link } from 'react-router-dom'
export default class Product extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            productList: this.props.productList,
            productId: this.props.id,
            product: this.props.productList[this.props.id]
        }
    }


    goToPayment = () => {
        this.setState({
            showProductDesc: true
        })
    }

    render() {

        let productDesc = <div className="card">
            <div className="card-title">
                {/* {this.state.product.username} */}
            </div>
            <div className="card-body">
            <div className="mycolumn myleft">
            <img src={profile} className="rounded" width="100" /><br/> &nbsp;{this.state.product.username}
            </div>
            <div className="mycolumn myright">
            <h3>{this.state.product.short_desc}</h3><br/>
                <h5>Item Condition: <strong>New</strong></h5>
                Description: {this.state.product.long_desc}<br/>
                Product Type: {this.state.product.product_type}<br/>
                <Bidding minbid={this.state.product.product_minimumbid} price={this.state.product.price} username={this.state.product.username}/>
              
                <table>
                    <tbody>
                        <tr>
                            <td>
                                <Link to="/payment">  <button onClick={this.goToPayment} className="btn btn-outline-primary">Buy Now</button></Link>
                            </td>
                        </tr>
                    </tbody>
                </table>
                </div>
            </div>
           
        </div>

        return (
            <div>
                {productDesc}
            </div>
        )
    }
}